/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


var btn = document.querySelector("#btn");
var div = document.querySelector("#mostrarMais");

div.style.display = "none";

btn.addEventListener("click", function() {

  if(div.style.display === "none") {
        div.style.display = "block";
        btn.innerHTML="Mostra Menos";
    } else {
      div.style.display = "none";
      btn.innerHTML="Mostra Mais";
  }
    
});