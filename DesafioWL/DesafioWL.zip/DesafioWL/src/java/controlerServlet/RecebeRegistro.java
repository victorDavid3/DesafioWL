/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlerServlet;

import controler.ControlerRegistro;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Registro;

/**
 *
 * @author victo
 */
@WebServlet(name = "RecebeRegistro", urlPatterns = {"/RecebeRegistro"})
public class RecebeRegistro extends HttpServlet {

@Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        String recebe_CPF = (req.getParameter("CPF"));
        String recebe_Nome = (req.getParameter("Nome"));
        String recebe_CafeManhaOp1 = (req.getParameter("CafeManhaOp1"));
        String recebe_CafeManhaOp2 = (req.getParameter("CafeManhaOp2"));
        String recebe_CafeManhaOp3 = (req.getParameter("CafeManhaOp3"));
        
        Registro registro = new Registro();
        
        registro.setNome(recebe_Nome);
        registro.setCpf(recebe_CPF);
        registro.setCafeManhaOp1(recebe_CafeManhaOp1);
        registro.setCafeManhaOp2(recebe_CafeManhaOp2);
        registro.setCafeManhaOp3(recebe_CafeManhaOp3);
        
        ControlerRegistro registroDAO = new ControlerRegistro();
        registroDAO.salvarRegistro(registro);
        
        resp.sendRedirect("/DesafioWL/registro/Registro.jsp");           

        
    }
}
