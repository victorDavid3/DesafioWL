/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;

import connection.ConexaoBD;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.Registro;

/**
 *
 * @author victo
 */
public class ControlerRegistro {
    
    private ConexaoBD conn = new ConexaoBD();
    
    public void salvarRegistro(Registro registro) {
        conn.conectarBD();

        String sql = "insert into registrocafedamanha(CPF, Nome, CafeManhaOp1, CafeManhaOp2, CafeManhaOp3) values(?,?,?,?,?)";

        PreparedStatement pst;
        try {
     
            pst = conn.conexao.prepareStatement(sql);

            pst.setString(1, registro.getCpf());
            pst.setString(2, registro.getNome());
            pst.setString(3, registro.getCafeManhaOp1());
            pst.setString(4, registro.getCafeManhaOp2());
            pst.setString(5, registro.getCafeManhaOp3());
       
            pst.execute();
            JOptionPane.showMessageDialog(null, "Registro salvo com sucesso!!!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar registro!!!");
            System.out.println("Erro ao salvar registro\n" + ex);
            
        }
    }
   
    public List<Registro> listarRegistro() {

        List<Registro> registros = new ArrayList();
        conn.conectarBD();
        PreparedStatement ps = null;
      
        ResultSet rs = null;
        try {
            ps = conn.conexao.prepareStatement("Select * from registrocafedamanha order by Nome");
            rs = ps.executeQuery();
         
            while (rs.next()) {
       
                Registro r = new Registro();
                r.setId(rs.getInt("id"));
                r.setNome(rs.getString("Nome"));
                r.setCpf(rs.getString("CPF"));
                r.setCafeManhaOp1(rs.getString("CafeManhaOp1"));
                r.setCafeManhaOp2(rs.getString("CafeManhaOp2"));
                r.setCafeManhaOp3(rs.getString("CafeManhaOp3"));
              
      
                registros.add(r);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao listar registros!!!");
            System.out.println("Erro ao listar registros" + ex);
            
        }
        conn.desconectarBD();
       
        return registros;
    }
    
    
}
