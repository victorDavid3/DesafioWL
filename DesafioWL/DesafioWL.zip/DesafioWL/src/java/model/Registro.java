/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author victo
 */
public class Registro {
    
    int id = 0;
    String nome= "";
    String cpf= "";
    String CafeManhaOp1= "";
    String CafeManhaOp2= "";
    String CafeManhaOp3= "";

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getCafeManhaOp1() {
        return CafeManhaOp1;
    }

    public void setCafeManhaOp1(String CafeManhaOp1) {
        this.CafeManhaOp1 = CafeManhaOp1;
    }

    public String getCafeManhaOp2() {
        return CafeManhaOp2;
    }

    public void setCafeManhaOp2(String CafeManhaOp2) {
        this.CafeManhaOp2 = CafeManhaOp2;
    }

    public String getCafeManhaOp3() {
        return CafeManhaOp3;
    }

    public void setCafeManhaOp3(String CafeManhaOp3) {
        this.CafeManhaOp3 = CafeManhaOp3;
    }
    
    
    
    
}
